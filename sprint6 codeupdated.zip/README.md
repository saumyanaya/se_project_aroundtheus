# Project name

Around The U.S.

# Description/Functionality

A gallery of images from around the U.S. Converts to display on various mobile screen sizes.

# Technologies/Techniques

HTML/CSS combines with @media at-rules to create different layouts depending on the screen size viewing.

# Github Pages

https://saumyanaya.github.io/se_project_aroundtheus/
